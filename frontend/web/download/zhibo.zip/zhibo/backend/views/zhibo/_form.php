<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use backend\models\Zhibo;
use backend\models\RoomRole;
use kartik\widgets\ActiveForm;
use kartik\select2\Select2;
use kartik\switchinput\SwitchInput;
use kartik\builder\Form;
use kartik\datecontrol\DateControl;

/**
 * @var yii\web\View $this
 * @var backend\models\Zhibo $model
 * @var yii\widgets\ActiveForm $form
 */
?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                网站设置
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-offset-2 col-lg-8">
                      <?php
                        $form = ActiveForm::begin(['type'=>ActiveForm::TYPE_HORIZONTAL,'options' => ['enctype' => 'multipart/form-data']]);
                        echo $form->field($model,"name")->textInput(['placeholder'=>'请输入房间名称', 'maxlength'=>255]);
                        echo $form->field($model,"title")->textInput(['placeholder'=>'请输入房间Title','rows'=> 6]);
                        echo $form->field($model,"keyword")->textarea(['placeholder'=>'请输入房间关键词','rows'=> 6]);
                        echo $form->field($model,"description")->textarea(['placeholder'=>'请输入房间描述','rows'=> 6]);
                        echo $form->field($model,"announcement")->textarea(['placeholder'=>'请输入房间公告','rows'=> 6]);
                        echo $form->field($model,'zhibo_tips')->textarea(['placeholder'=>'这里的公告将用于输入框上方','rows'=> 6]);
                        $errors=$model->hasErrors()?$model->errors:[];
                      ?>

                        <div class="field-zhibo-logo_attr <?=(!empty($errors['logo_attr'])||!empty($errors['logo']))?"has-error":"";?>">
                            <label class="control-label col-md-2" for="zhibo-logo_attr">直播室logo</label>
                            <div class="col-md-10">
                                <div type="button" class="btn btn-outline btn-primary" id="uploadlogo">上传</div>
                                <input type="hidden" name="Zhibo[logo]" value="<?=$model->logo;?>" id="logoval"/>
                                </br>
                                </br>
                                <?php
                                  if(!$model->isNewRecord){
                                      echo Html::img($model->logo,['id'=>'logo_image','style'=>'width:200px']);
                                  }
                                ?>
                            </div>
                            <div class="col-md-offset-2 col-md-10"></div>
                            <div class="col-md-offset-2 col-md-10"><div class="help-block"><?=(!empty($errors['logo_attr']) || !empty($errors['logo']))?(!empty($errors['logo_attr'])?$errors['logo_attr'][0]:$errors['logo'][0]):"";?></div></div>
                        </div>
                      <?php
                        echo $form->field($model,"allowroles")->widget(Select2::className(),[
                            'data'=>ArrayHelper::map(RoomRole::getallroles(),'id','name'),
                            'options'=>[
                                'multiple'=>true
                            ]
                        ]);

                        echo $form->field($model,"loadguest")->widget(SwitchInput::className(),[
                           'pluginOptions' => [
                              'onText' => '加载',
                              'offText' => '不加载',
                           ]
                        ]);
                        echo $form->field($model,"show_msgtime")->widget(SwitchInput::className(),[
                           'pluginOptions' => [
                              'onText' => '显示',
                              'offText' => '不显示',
                           ]
                       ]);
                        echo $form->field($model,"show_footer")->widget(SwitchInput::className(),[
                           'pluginOptions' => [
                              'onText' => '显示',
                              'offText' => '不显示',
                           ]
                        ]);
                        echo $form->field($model,"footer_text")->textarea(['placeholder'=>'页脚文字','rows'=> 8]);

                        echo $form->field($model,"status")->widget(SwitchInput::className(),[
                            'pluginOptions' => [
                                'onText' => '正常',
                                'offText' => '维护',
                            ]
                        ]);

                      ?>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-default"><?=$model->isNewRecord ? Yii::t('app', '创建') : Yii::t('app', '更新')?></button>
                            </div>
                        </div>
                      <?php
                        ActiveForm::end();
                      ?>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!--row-->
</div>
<?php
$this->registerJsFile("@web/plupload/plupload.full.min.js",['depends'=>\backend\assets\AceAsset::className()]);
$js1=<<<JS
    $(function(){
          $("#configform .switch input[type=\"checkbox\"],#configform .switch  input[type=\"radio\"]").bootstrapSwitch();
          $("#configform .switch input[type=\"checkbox\"]").on('switchChange.bootstrapSwitch', function (event, state) {
                if(state){
                    $(this).val(1);
                }
                else{
                    $(this).val(0);
                }
                console.log(this);
          });
    });
JS;

$this->registerJs($js1, $this::POS_END, 'site-config');
$js2="
   /****/
   upload_button=$('#uploadlogo');
   var uploader = new plupload.Uploader({
       runtimes : 'html5,flash,silverlight,html4',
       browse_button : upload_button.get(0),
       url : '".Yii::$app->urlManager->createUrl(['site/upload'])."',
       flash_swf_url : '".Yii::getAlias("@web/plupload/Moxie.swf")."',
       silverlight_xap_url : '".Yii::getAlias("@web/plupload/Moxie.xap")."',
       filters: {
          mime_types : [
             { title : '图片文件', extensions : 'jpg,gif,png,bmp,jpeg'},
          ],
          prevent_duplicates : true //不允许队列中存在重复文件
       },
       multipart_params:{
		   '".Yii::$app->request->csrfParam."':'".Yii::$app->request->getCsrfToken()."'
      }
   });
   uploader.init(); //初始化

   uploader.bind('FilesAdded',function(uploader,files){
		uploader.start(); //开始上传
   });
   uploader.bind('FileUploaded',function(uploader,files,responseObject){
        var dataobj = jQuery.parseJSON(responseObject.response);
        if(!dataobj.error){
           $('#logoval').val(dataobj.src);
           $('#logo_image').attr('src',dataobj.src);
        }
        else{
           alert(dataobj.msg);
        }
   });
   uploader.bind('Error',function(uploader,errObject){
      console.log(errObject.response);
      alert(errObject.message);
   });
";
$this->registerJs($js2, $this::POS_END, 'logo_upload');
?>
