<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use kartik\grid\GridView;
use yii\widgets\Pjax;
use \backend\models\User;
use backend\models\RoomRole;
use backend\models\Shouted;

/**
 * @var yii\web\View $this
 * @var yii\data\ActiveDataProvider $dataProvider
 * @var backend\models\UserSearch $searchModel
 */

$this->title = '直播室用户';
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index">
    <div class="page-header">
            <h1><?= Html::encode($this->title) ?></h1>
    </div>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?php /* echo Html::a('Create User', ['create'], ['class' => 'btn btn-success'])*/  ?>
    </p>

    <?php Pjax::begin(); echo GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],
            [
                'attribute'=>'id',
                'width'=>'100px'
            ],
            [
                'attribute'=>'username',
                'width'=>'200px'
            ],
            [
                'attribute'=>'ncname',
                'width'=>'200px'
            ],
            //'auth_key',
            //'password_hash',
            //'password_reset_token',
            [
                'attribute'=>'mobile',
            ],
            [
                'attribute'=>'email',
                'format'=>'email',
                'width'=>'200px'
            ],
            [
                'attribute'=>'teacher',
                'value'=>function($model){
                    if($model->teacher&&isset(Shouted::$postnames[$model->teacher])){
                        return Shouted::$postnames[$model->teacher];
                    }
                    else{
                        return "";
                    }
                },
                'filterType' => GridView::FILTER_SELECT2,
                'filter' =>Shouted::$postnames,
                'filterWidgetOptions' => [
                    'pluginOptions' => ['allowClear' => true],
                ],
                'filterInputOptions' => ['placeholder' => '所属老师'],
            ],
            [
                'attribute'=>'roomrole',
                'value'=>function($model){
                        if($model->roomrole){
                            return RoomRole::findOne($model->roomrole)->name;
                        }
                        else{
                            return "";
                        }
                 },
                'filterType' => GridView::FILTER_SELECT2,
                'width'=>'200px',
                'filter' => ArrayHelper::map(RoomRole::getallroles(),'id','name'),
                'filterWidgetOptions' => [
                    'pluginOptions' => ['allowClear' => true],
                ],
                'filterInputOptions' => ['placeholder' => '房间角色'],
            ],
            [
                'attribute'=>'zhiboid',
                'value'=>function($model){
                    if(!empty(Yii::$app->params['zhibo_list'][$model->zhiboid])){
                        return Yii::$app->params['zhibo_list'][$model->zhiboid];
                    }
                    else{
                        return $model->zhiboid;
                    }
                },
                'filterType' => GridView::FILTER_SELECT2,
                'width'=>'200px',
                'filter' => !empty(Yii::$app->params['zhibo_list'])?Yii::$app->params['zhibo_list']:[],
                'filterWidgetOptions' => [
                    'pluginOptions' => ['allowClear' => true],
                ],
                'filterInputOptions' => ['placeholder' => '所属房间'],
            ],
            [
                'attribute'=>'role',
                'value'=>function($model){
                        if($model->role){
                            $roles=unserialize($model->role);
                            $rolemodels=backend\models\RbacModel::findAll($roles);
                            $role_data=array_keys(ArrayHelper::map($rolemodels,'description','name'));
                            return implode(",",$role_data);
                        }
                        else{
                            return "";
                        }
                },
                'filterType' => GridView::FILTER_SELECT2,
                'width'=>'200px',
                'filter' => false,
                'filterWidgetOptions' => [
                    'pluginOptions' => ['allowClear' => true],
                ],
            ],
            [
                'attribute'=>'created_at',
                'format'=>'datetime',
                'filter'=>false
            ],
            [
                'attribute'=>'status',
                'value'=>function($model){
                       return User::$status[$model->status];
                },
                'filterType' => GridView::FILTER_SELECT2,
                'width'=>'200px',
                'filter' => User::$status,
                'filterWidgetOptions' => [
                    'pluginOptions' => ['allowClear' => true],
                ],
                'filterInputOptions' => ['placeholder' => '用户状态'],
            ],
            //'updated_at:datetime',

            [
                'class' => 'yii\grid\ActionColumn',
                'buttons' => [
                'update' => function ($url, $model) {
                                    return Html::a('<span class="glyphicon glyphicon-pencil"></span>', Yii::$app->urlManager->createUrl(['user/update','id' => $model->id,'edit'=>'t']), [
                                                    'title' => Yii::t('yii', 'Edit'),
                                                  ]);}

                ],
            ],
        ],
        'responsive'=>true,
        'hover'=>true,
        'condensed'=>true,
        'floatHeader'=>false,




        'panel' => [
            'heading'=>'<h3 class="panel-title"><i class="glyphicon glyphicon-th-list"></i></h3>',
            'type'=>'info',
            'before'=>Html::a('<i class="glyphicon glyphicon-plus"></i> Add', ['create'], ['class' => 'btn btn-success']),                                                                                                                                                          'after'=>Html::a('<i class="glyphicon glyphicon-repeat"></i> Reset List', ['index'], ['class' => 'btn btn-info']),
            'showFooter'=>false
        ],
        'exportConfig' => [
            GridView::TEXT=>[],
            GridView::HTML=>[],
            GridView::EXCEL=>[],
            GridView::JSON=>[],
            GridView::CSV => ['label' => '保存为CSV'],
        ]
    ]); Pjax::end(); ?>

</div>
